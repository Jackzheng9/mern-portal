async function loadApp() {
  await import("./server.js");
}
loadApp();